Compilation :
make

Génération des graphes :
dans le dossier "/graphs"
./script

Compilation, exécution et génération des courbes résultats :
./learning "nombre de parties" "banque initiale des IAs"

Nous recommandons 250000 parties pour que le système se stabilise clairement.

Pour reprendre un apprentissage à zéro :
Copier-coller les fichiers "BrainAX.txt" contenus dans le dossier agents_save et les mettre dans le repertoire principale src avant l'exécution du script.
Des exemples d'agents entrainés sont disponible dans le dossier trained_brain

